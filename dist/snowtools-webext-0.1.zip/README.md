# ServiceNow Tool belt

This extension was built to help ServiceNow developpers with every day tasks.
* list the open tabs, grouped by instance
* for older UI versions, change the tab name from "ServiceNow" to the actual content name

